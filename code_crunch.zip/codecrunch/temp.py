import mysql.connector
import streamlit
mydb = mysql.connector.connect(user='root', password='tiger',host='localhost', database='resume',auth_plugin='mysql_native_password')
if(mydb):
    print("HELLO WORLD")