show databases;
use resumes;
show tables;
create table HR(Position varchar(25) not null,Experience int not null);
desc HR;
select * from hr;
truncate table hr;
