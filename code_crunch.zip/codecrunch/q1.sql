show databases;
use resumes;
show tables;
select * from employees;
truncate table employees;